<?php

function get_conn()
{

$servername = "localhost";
$username = "test1";
$password = "csl451";
$dbname = "tnp";
$conn = new PDO("pgsql:host=$servername;dbname=$dbname",$username,$password);

return $conn;
}

?>


