<?php include 'header.php';?>
		<div id="page-wrapper">
			<p> Stats go here.</p>
		</div>
	</div>
	<script>
		$('#sidebar5').addClass('active');
	</script>
	</body>

</html>

